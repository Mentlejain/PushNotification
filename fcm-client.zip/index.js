// import { join } from 'node:path';
// import { fileURLToPath } from 'node:url';
// import { createServer } from 'node:http';

// import express from 'express';
// import { Server as WSServer } from 'socket.io';
import { initializeApp } from 'firebase/app';
import { getMessaging, onMessage, getToken } from "firebase/messaging";
import { onBackgroundMessage } from "firebase/messaging/sw";

const firebaseConfig = {
  apiKey: "AIzaSyD6UWWHVF0xh4TccXr58xRdP0LicT8Ln5M",
  authDomain: "shastacloud-1337.firebaseapp.com",
  projectId: "shastacloud-1337",
  storageBucket: "shastacloud-1337.appspot.com",
  messagingSenderId: "84706649851",
  appId: "1:84706649851:web:6f2596869539faaa95725e",
  measurementId: "G-70K58JPNX8"
};
// const app = express();
// const server = createServer(app);
// const io = new WSServer(server);
const firebaseClient = initializeApp(firebaseConfig);
const messaging = getMessaging(firebaseClient);

getToken(messaging, null).then((currentToken) => {
  if (currentToken) {
    // Send the token to your server and update the UI if necessary
    console.log(currentToken)
    // ...
  } else {
    // Show permission request UI
    console.log('No registration token available. Request permission to generate one.');
    // ...
  }
}).catch((err) => {
  console.log('An error occurred while retrieving token. ', err);
  // ...
});

// const __dirname = dirname(fileURLToPath(import.meta.url));

// app.get('/', (req, res) => {
//     res.sendFile(join(__dirname, 'public', 'index.htm'));
// });

// io.on('connection', (socket) => {
//     console.log('a user connected');
//     console.log(socket.id);
//     socket.on('disconnect', () => {
//         console.log('user disconnected');
//     });
// });

// server.listen(3000, () => {
//     console.log('listening on http://127.0.0.1:3000');
// });

function showNotification(data) {
    if (!("Notification" in window)) {
        alert("This browser does not support desktop notification");
    }
    else if (Notification.permission === "granted") {
        const notification = new Notification(data.title, {
            body: data.body,
        });
    }
    else if (Notification.permission !== "denied") {
        Notification.requestPermission().then((permission) => {
            if (permission === "granted") {
                const notification = new Notification(data.title, {
                    body: data.body,
                    renotify: true,
                    tag: 'notification',
                });
            }
        });
    }
}

onMessage(messaging, (payload) => {
    console.log('Message received. ', payload);
    // io.emit('notification', payload);
    showNotification(payload.notification);
});